import { cfg } from '../../config-loader';

export interface StackProps {
  stackName?: string;
  vpcId?: string;
}

export const defaultStackProps: StackProps = {
  stackName: cfg.stack.name,
  vpcId: cfg.stack.vpcId,
};
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { cfg } from '../../config-loader';

export interface LambdaProps {
  functionName: string;
  runtime?: lambda.Runtime;
  timeout?: number;
  memorySize?: number;
  stackNames?: string[];
  vpcId?: string;
  subnetIds?: string[];
  securityGroupIds?: string[];
  iamRoleArn?: string; 
}

export const defaultLambdaProps: LambdaProps = {
  functionName: cfg.lambda.functionName,
  runtime: lambda.Runtime.NODEJS_18_X,
  timeout: cfg.lambda.timeout,
  memorySize: cfg.lambda.memorySize,
  stackNames: cfg.lambda.stackNames,
  vpcId: cfg.lambda.vpcId,
  subnetIds: cfg.lambda.subnetIds,
  securityGroupIds: cfg.lambda.securityGroupIds,
  iamRoleArn: cfg.lambda.iamRoleArn,
};

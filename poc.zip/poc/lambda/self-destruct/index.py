import os
import logging
import boto3
from botocore.exceptions import ClientError

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize the CloudFormation client
cf_client = boto3.client('cloudformation')

def handler(event, context):
    """
    Lambda handler to delete the CloudFormation stack identified by STACK_ID env var.
    Triggered by EventBridge or direct invocation.
    """
    stack_id = os.getenv('STACK_ID')
    if not stack_id:
        logger.error("No STACK_ID environment variable found – aborting delete.")
        return

    try:
        logger.info(f"Initiating deletion of stack: {stack_id}")
        cf_client.delete_stack(StackName=stack_id)
        logger.info(f"DeleteStack command successfully issued for: {stack_id}")
    except ClientError as err:
        logger.error(f"Failed to delete stack {stack_id}: {err}", exc_info=True)
        # Reraise to mark the invocation as failed
        raise

import { Duration } from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as path from 'path';
import { Construct } from 'constructs';
import { LambdaProps } from './props/lambda-props';

export function createDestroyLambda(
  scope: Construct,
  props: LambdaProps
): lambda.IFunction {
  // Import the IAM Role by ARN
  const role = iam.Role.fromRoleArn(
    scope,
    `DestroyLambdaRole-${props.functionName}`,
    props.iamRoleArn,
    { mutable: false }
  );

  // Lookup the VPC by ID
  const vpc = ec2.Vpc.fromLookup(scope, `LambdaVPC-${props.functionName}`, {
    vpcId: props.vpcId,
  });

  // Import subnets by ID
  const subnets = props.subnetIds.map((sid, idx) =>
    ec2.Subnet.fromSubnetId(scope, `${props.functionName}-Subnet${idx}`, sid)
  );

  // Import security groups by ID
  const securityGroups = props.securityGroupIds.map((sgId, idx) =>
    ec2.SecurityGroup.fromSecurityGroupId(
      scope,
      `${props.functionName}-SG${idx}`,
      sgId
    )
  );

  return new lambda.Function(scope, `${props.functionName}-Function`, {
    functionName: props.functionName,
    runtime: props.runtime,
    handler: 'index.handler',
    code: lambda.Code.fromAsset(
      path.resolve(__dirname, '..', '..', 'lambda', 'self-destruct')
    ),
    memorySize: props.memorySize,
    timeout: Duration.seconds(props.timeout),
    role,
    vpc,
    vpcSubnets: { subnets },
    securityGroups,
    environment: {
      // Focus on deleting the auto-generated stack ID
      STACK_ID: props.stackNames[0],
    },
  });
}

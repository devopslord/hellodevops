import { aws_events as events } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { LambdaFunction } from 'aws-cdk-lib/aws-events-targets';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { EventBridgeProps } from './props/eventbridge-props';

export function createSelfDestructRule(
  scope: Construct,
  targetFn: lambda.IFunction,
  props: EventBridgeProps
): events.Rule {
  return new events.Rule(scope, 'SelfDestructRule', {
    ruleName: props.ruleName,
    schedule: events.Schedule.expression(props.scheduleExpression),
    targets: [new LambdaFunction(targetFn)],
  });
}

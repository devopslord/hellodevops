import { cfg } from '../../config-loader';

export interface EventBridgeProps {
  ruleName?: string;
  scheduleExpression: string;
}

export const defaultEventBridgeProps: EventBridgeProps = {
  scheduleExpression: cfg.eventbridge.scheduleExpression, // ← lower-case
  ruleName:            cfg.eventbridge.ruleName,          // optional
};

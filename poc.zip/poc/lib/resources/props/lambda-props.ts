import { Runtime } from 'aws-cdk-lib/aws-lambda';

export interface LambdaProps {
  functionName: string;
  runtime: Runtime;
  timeout: number;
  memorySize: number;
  stackNames: string[];
  vpcId: string;
  subnetIds: string[];
  securityGroupIds: string[];
  iamRoleArn: string;
  /**
   * Optional tags to apply to the Lambda function.
   */
  tags?: Record<string, string>;
  /**
   * The environment group for this function (dev, qa, prod).
   */
  environmentGroup?: string;
  /**
   * Optional environment variables to inject into the function.
   */
  environment?: Record<string, string>;
}

// index-props.ts

export interface StackProps {
  /**
   * CloudFormation stack name (optional override)
   */
  stackName?: string;
  /**
   * VPC ID for the stack (optional override)
   */
  vpcId?: string;
}

/**
 * Default stack properties can be overridden by explicitly passing in props.
 * Removed config-loader dependency—pass stackName and vpcId directly when instantiating your stacks.
 */
export const defaultStackProps: StackProps = {};

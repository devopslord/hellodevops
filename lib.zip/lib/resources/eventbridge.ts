// lib/resources/eventbridge.ts
import * as events from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
import { Construct } from 'constructs';
import { EventBridgeProps } from './props/eventbridge-props';
import { Function as LambdaFunction } from 'aws-cdk-lib/aws-lambda';

export function createSelfDestructRule(
  scope: Construct,
  lambda: LambdaFunction,
  props: EventBridgeProps
): events.Rule {
  const rule = new events.Rule(scope, 'SelfDestructRule', {
    schedule: events.Schedule.expression(props.scheduleExpression),
  });

  rule.addTarget(new targets.LambdaFunction(lambda));

  return rule;
}

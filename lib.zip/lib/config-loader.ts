import * as fs from 'fs';
import * as yaml from 'yaml';
import * as path from 'path';

// Define the path to the YAML file correctly
const yamlPath = path.resolve(__dirname, '../config/config.yaml');

// Read and parse the YAML configuration
export const cfg = yaml.parse(fs.readFileSync(yamlPath, 'utf8'));

// CommonJS requires
const {
  CloudFormationClient,
  DeleteStackCommand,
} = require('@aws-sdk/client-cloudformation');

const cf = new CloudFormationClient({});

exports.handler = async (event) => {
  const stacksEnv = process.env.STACK_NAMES ?? '';
  if (!stacksEnv) {
    console.log('No STACK_NAMES env var found – nothing to do.');
    return { statusCode: 200, body: 'No stacks provided.' };
  }

  const stackNames = stacksEnv.split(',').map((s) => s.trim()).filter(Boolean);

  for (const stackName of stackNames) {
    try {
      console.log(`Deleting stack: ${stackName}`);
      await cf.send(new DeleteStackCommand({ StackName: stackName }));
    } catch (err) {
      console.error(`Failed to delete ${stackName}:`, err);
    }
  }

  return {
    statusCode: 200,
    body: `Triggered deletion for ${stackNames.length} stack(s)`,
  };
};

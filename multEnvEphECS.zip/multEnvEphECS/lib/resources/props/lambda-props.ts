import { Runtime } from 'aws-cdk-lib/aws-lambda';

export interface LambdaProps {
  functionName: string;
  runtime: Runtime;
  timeout: number;
  memorySize: number;
  stackNames: string[];
  vpcId: string;
  subnetIds: string[];
  securityGroupIds: string[];
  iamRoleArn: string;
  /**
   * The environment group for this function (e.g., dev, qa, prod).
   */
  environmentGroup?: string;
  /**
   * Optional environment variables to inject into the function.
   * We’ll use this to pass through STACK_ID, ENV, or others at deploy time.
   */
  environment?: Record<string, string>;
}

import { aws_lambda as lambda, Duration } from 'aws-cdk-lib';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import * as path from 'path';

import { cfg } from '../config-loader';
import { createAvenueRole } from './avenue';
import { AvenueRoleProps } from './props/avenue-props';

/**
 * Creates (or references) the self-destruct Lambda function.
 * ────────────────────────────────────────────────────────────
 * Role logic:
 *   • If `cfg.lambda.iamRoleArn` is supplied → import that role.
 *   • Otherwise → build a fresh Avenue role from inline policy docs.
 */
export function createDestroyLambda(scope: Construct): lambda.Function {
  // ── 1. Execution role ──────────────────────────────────────────────────────
  const role: iam.IRole = cfg.lambda.iamRoleArn && cfg.lambda.iamRoleArn.trim()
    ? iam.Role.fromRoleArn(scope, 'ImportedLambdaRole', cfg.lambda.iamRoleArn, {
        mutable: false,
      })
    : createAvenueRole(scope, AvenueRoleProps);

  // ── 2. Network plumbing ────────────────────────────────────────────────────
  const vpc = ec2.Vpc.fromLookup(scope, 'LambdaVpc', {
    vpcId: cfg.stack.vpcId,
  });

  const subnets = cfg.lambda.subnetIds.map((id: string, idx: number) =>
    ec2.Subnet.fromSubnetId(scope, `LambdaSubnet${idx}`, id),
  );

  const securityGroups = cfg.lambda.securityGroupIds.map((id: string, idx: number) =>
    ec2.SecurityGroup.fromSecurityGroupId(scope, `LambdaSG${idx}`, id),
  );

  // ── 3. Lambda definition (NodejsFunction bundles source + deps) ────────────
  return new lambda.Function(scope, cfg.lambda.functionName, {
  runtime: lambda.Runtime.NODEJS_18_X,
  handler: 'index.handler',  // <-- must match export name in index.js
  code: lambda.Code.fromAsset(
    path.join(__dirname, '..', '..', 'lambda', 'self-destruct')
  ),
  memorySize: cfg.lambda.memorySize,
  timeout: Duration.seconds(cfg.lambda.timeout),
  role,
  vpc,
  vpcSubnets: { subnets },
  securityGroups,
  environment: {
    STACK_NAMES: cfg.lambda.stackNames.join(','),
  },
});

}

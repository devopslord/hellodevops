// import { aws_lambda as lambda, Duration } from 'aws-cdk-lib';
// import * as iam from 'aws-cdk-lib/aws-iam';
// import * as ec2 from 'aws-cdk-lib/aws-ec2';
// import { Construct } from 'constructs';
// import * as path from 'path';

// import { cfg } from '../config-loader';

// /**
//  * Creates the self-destruct Lambda function using a pre-built JS handler.
//  */
// export function createDestroyLambda(scope: Construct): lambda.Function {
//   // ── 1. Import execution role ──────────────────────────────────────────────
//   if (!cfg.lambda || !cfg.lambda.iamRoleArn) {
//     throw new Error('Missing lambda.iamRoleArn in configuration');
//   }

//   const role = iam.Role.fromRoleArn(scope, 'ImportedLambdaRole', cfg.lambda.iamRoleArn, {
//     mutable: false,
//   });

//   // ── 2. Network setup ───────────────────────────────────────────────────────
//   const vpc = ec2.Vpc.fromLookup(scope, 'LambdaVpc', {
//     vpcId: cfg.stack.vpcId,
//   });

//   const subnets = cfg.lambda.subnetIds.map((id: string, idx: number) =>
//     ec2.Subnet.fromSubnetId(scope, `LambdaSubnet${idx}`, id),
//   );

//   const securityGroups = cfg.lambda.securityGroupIds.map((id: string, idx: number) =>
//     ec2.SecurityGroup.fromSecurityGroupId(scope, `LambdaSG${idx}`, id),
//   );

//   // ── 3. Define Lambda function ──────────────────────────────────────────────
//   return new lambda.Function(scope, cfg.lambda.functionName, {
//     runtime: lambda.Runtime.NODEJS_18_X,
//     handler: 'index.handler', // Ensure `index.js` exports `handler`
//     code: lambda.Code.fromAsset(
//       path.join(__dirname, '..', '..', 'lambda', 'self-destruct')
//     ),
//     memorySize: cfg.lambda.memorySize,
//     timeout: Duration.seconds(cfg.lambda.timeout),
//     role,
//     vpc,
//     vpcSubnets: { subnets },
//     securityGroups,
//     environment: {
//       STACK_NAMES: cfg.lambda.stackNames.join(','),
//     },
//   });
// }


import { aws_lambda as lambda, Duration } from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import * as path from 'path';

import { cfg } from '../config-loader';

/**
 * Creates the self-destruct Lambda function using a pre-built JS handler.
 */
export function createDestroyLambda(scope: Construct): lambda.Function {
  // ── 1. Import execution role ──────────────────────────────────────────────
  if (!cfg.lambda || !cfg.lambda.iamRoleArn) {
    throw new Error('Missing lambda.iamRoleArn in configuration');
  }

  const role = iam.Role.fromRoleArn(
    scope,
    'ImportedLambdaRole',
    cfg.lambda.iamRoleArn,
    { mutable: false }
  );

  // ── 2. Network setup ───────────────────────────────────────────────────────
  const vpc = ec2.Vpc.fromLookup(scope, 'LambdaVpc', {
    vpcId: cfg.stack.vpcId,
  });

  const subnets = cfg.lambda.subnetIds.map((id: string, idx: number) =>
    ec2.Subnet.fromSubnetId(scope, `LambdaSubnet${idx}`, id)
  );

  const securityGroups = cfg.lambda.securityGroupIds.map((id: string, idx: number) =>
    ec2.SecurityGroup.fromSecurityGroupId(scope, `LambdaSG${idx}`, id)
  );

  // ── 3. Define Lambda function ──────────────────────────────────────────────
  const destroyLambda = new lambda.Function(scope, cfg.lambda.functionName, {
    functionName: cfg.lambda.functionName,
    runtime: lambda.Runtime.NODEJS_18_X,
    handler: 'index.handler', // Make sure index.ts exports `handler`
    code: lambda.Code.fromAsset(
      path.resolve(__dirname, '..', '..', 'lambda', 'self-destruct') // Absolute path to lambda folder
    ),
    memorySize: cfg.lambda.memorySize,
    timeout: Duration.seconds(cfg.lambda.timeout),
    role: role,
    vpc: vpc,
    vpcSubnets: { subnets },
    securityGroups: securityGroups,
    environment: {
      STACK_NAMES: cfg.lambda.stackNames.join(','),
    },
  });

  return destroyLambda;
}
import { Construct } from 'constructs';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as fs from 'fs';
import * as path from 'path';
import { AvenueRoleProps } from './props/avenue-props';

/**
 * Build an IAM role for Lambda by attaching inline policy documents stored
 * in `resources/iam/`. Each JSON file can be either:
 *   • a full IAM policy document (Version + Statement[]), **or**
 *   • a single statement object.
 */
export function createAvenueRole(scope: Construct, props: AvenueRoleProps): iam.Role {
  const role = new iam.Role(scope, props.roleName, {
    assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
  });

  props.policyDocuments.forEach((filename, idx) => {
    const filePath = path.join(__dirname, 'iam', filename);
    if (!fs.existsSync(filePath)) {
      throw new Error(`Policy file not found: ${filePath}`);
    }
    const json = JSON.parse(fs.readFileSync(filePath, 'utf8'));

    // If the file is a full policy document, iterate through its statements.
    if (json.Statement) {
      const doc = iam.PolicyDocument.fromJson(json);
      role.attachInlinePolicy(
        new iam.Policy(scope, `${props.roleName}-Policy${idx}`, { document: doc }),
      );
    } else {
      // Treat as a single statement object
      role.addToPolicy(iam.PolicyStatement.fromJson(json));
    }
  });

  return role;
}

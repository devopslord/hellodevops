import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';

import { createDestroyLambda } from './resources/lambda';
import { createSelfDestructRule } from './resources/eventbridge';
import { LambdaProps } from './resources/props/lambda-props';
import { EventBridgeProps } from './resources/props/eventbridge-props';

export interface EphemeralFargateStackProps extends cdk.StackProps {
  vpcId: string;
  subnetIds: string[];
  serviceSecurityGroups: string[];
  lambdaProps: LambdaProps;
  eventBridgeProps: EventBridgeProps;
}

export class EphemeralFargateStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: EphemeralFargateStackProps) {
    super(scope, id, props);

    // Lookup the existing VPC (requires CDK bootstrap trust in target accounts)
    const vpc = ec2.Vpc.fromLookup(this, 'ImportedVPC', {
      vpcId: props.vpcId,
    });

    // Deploy the cleanup Lambda and schedule
    const destroyLambda = createDestroyLambda(this, props.lambdaProps);
    createSelfDestructRule(this, destroyLambda, props.eventBridgeProps);
  }
}

import { Duration } from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as path from 'path';
import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { LambdaProps } from './props/lambda-props';

export function createDestroyLambda(
  scope: Construct,
  props: LambdaProps
): lambda.IFunction {
  const role = iam.Role.fromRoleArn(
    scope,
    `DestroyLambdaRole-${props.functionName}`,
    props.iamRoleArn,
    { mutable: false }
  );

  const vpc = ec2.Vpc.fromLookup(scope, `LambdaVPC-${props.functionName}`, {
    vpcId: props.vpcId,
  });

  const subnets = props.subnetIds.map((sid, idx) =>
    ec2.Subnet.fromSubnetId(scope, `${props.functionName}-Subnet${idx}`, sid)
  );

  const securityGroups = props.securityGroupIds.map((sgId, idx) =>
    ec2.SecurityGroup.fromSecurityGroupId(scope, `${props.functionName}-SG${idx}`, sgId)
  );

  const fn = new lambda.Function(scope, `${props.functionName}-Function`, {
    functionName: props.functionName,
    runtime:      lambda.Runtime.PYTHON_3_9,
    handler:      'index.handler',                      // index.py → handler()
    code:         lambda.Code.fromAsset(
      path.resolve(__dirname, '..', '..', 'lambda', 'self-destruct')
    ),
    memorySize:   props.memorySize,
    timeout:      Duration.seconds(props.timeout),
    role,
    vpc,
    vpcSubnets:   { subnets },
    securityGroups,
    environment: {
      STACK_ID: props.stackNames[0],
      ...props.environment,
    },
  });

  if (props.tags) {
    for (const [k, v] of Object.entries(props.tags)) {
      cdk.Tags.of(fn).add(k, v);
    }
  }

  return fn;
}

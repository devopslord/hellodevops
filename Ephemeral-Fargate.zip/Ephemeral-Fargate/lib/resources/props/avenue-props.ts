import { cfg } from '../../config-loader';

export interface AvenueRoleProps {
  roleName: string;
  policyDocuments: string[];
}

export const AvenueRoleProps: AvenueRoleProps = {
  roleName: cfg.avenue.roleName,
  policyDocuments: cfg.avenue.policyDocuments,
};

export interface EventBridgeProps {
  ruleName: string;
  scheduleExpression: string;
}
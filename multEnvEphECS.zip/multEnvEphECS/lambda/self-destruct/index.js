// index.js - Self-Destruct Lambda Handler
const { CloudFormationClient, DeleteStackCommand } = require("@aws-sdk/client-cloudformation");

// Initialize the CloudFormation client
const cf = new CloudFormationClient({});

/**
 * Lambda handler to delete the CloudFormation stack identified by STACK_ID env var
 */
exports.handler = async (event, context) => {
  const stackId = process.env.STACK_ID;
  if (!stackId) {
    console.error("No STACK_ID environment variable found – aborting delete.");
    return;
  }

  try {
    console.info(`Initiating deletion of stack: ${stackId}`);
    const command = new DeleteStackCommand({ StackName: stackId });
    await cf.send(command);
    console.info(`DeleteStack command successfully issued for: ${stackId}`);
  } catch (err) {
    console.error(`Failed to delete stack ${stackId}:`, err);
    // Rethrow so Lambda marks this invocation as an error
    throw err;
  }
};

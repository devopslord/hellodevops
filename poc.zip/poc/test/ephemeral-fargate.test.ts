import { App } from 'aws-cdk-lib';
import { EphemeralFargateStack } from '../lib/ephemeral-fargate-stack';

test('Stack compiles', () => {
  const app = new App();
  new EphemeralFargateStack(app, 'TestStack', {});
});
